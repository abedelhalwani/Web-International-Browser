Web International Browser

1. Extract all files from this ZIP into a folder.
2. Open WebInternationalBrowser.exe.

The Microsoft Edge WebView2 Runtime must be installed. If Windows reports that
the runtime is missing, install the Evergreen WebView2 Runtime from Microsoft:
https://developer.microsoft.com/microsoft-edge/webview2/
