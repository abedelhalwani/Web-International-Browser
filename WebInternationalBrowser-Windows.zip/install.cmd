@echo off
set "D=%LOCALAPPDATA%\WebInternationalBrowser"
mkdir "%D%" 2>nul
copy /y *.exe "%D%\" >nul
copy /y *.dll "%D%\" >nul
copy /y *.ico "%D%\" >nul
del "%D%\WebInternationalBrowserSetup.exe" 2>nul
powershell -NoProfile -Command "$s=(New-Object -ComObject WScript.Shell).CreateShortcut([Environment]::GetFolderPath('Desktop')+'\Web International Browser.lnk'); $s.TargetPath='%D%\WebInternationalBrowser.exe'; $s.WorkingDirectory='%D%'; $s.IconLocation='%D%\Web International Browser.ico,0'; $s.Save()"
start "" "%D%\WebInternationalBrowser.exe"
